using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OrtizAbrahamSprint3.Pages
{
    public class ClassesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
